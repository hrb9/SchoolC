#ifndef _TREE_PRINT_LIBRARY_HEADER_

struct TreeNode;// forward declaration

extern __declspec(dllimport) void print_ascii_tree(TreeNode* t);

#endif // !_TREE_PRINT_LIBRARY_HEADER_