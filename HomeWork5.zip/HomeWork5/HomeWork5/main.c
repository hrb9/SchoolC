#include <stdlib.h>
#include <time.h>
#include "BST.h"
#include "TreePrintLibrary.h"

int main()
{
	srand((long)time(NULL));
	BST bst;
	BST* bstPtr = &bst;

	initBST(bstPtr);

/*	for (int i = 0; i < 5; i++){
		insertBST(bstPtr, rand() % 1000);
		insertBST(bstPtr,5);
	insertBST(bstPtr, 8);
	insertBST(bstPtr, 8);
	insertBST(bstPtr, 8);
	insertBST(bstPtr, 9);
	insertBST(bstPtr, 9);
	insertBST(bstPtr, 2);
	insertBST(bstPtr, 4);
	insertBST(bstPtr, 1);
	} */

	insertBST(bstPtr, 5);
	insertBST(bstPtr, 8);
	insertBST(bstPtr, 8);
	insertBST(bstPtr, 8);
	insertBST(bstPtr, 9);
	insertBST(bstPtr, 9);
	insertBST(bstPtr, 2);
	insertBST(bstPtr, 4);
	insertBST(bstPtr, 1);


	print_ascii_tree(bstPtr->root);

	printf("\n");

	printTreeReversedInorder(bstPtr);
	printf("\n %d,%d \n", sameHeightLeaves(bstPtr),heightRec(bstPtr->root));


	destroyBST(bstPtr);

	return 0;
}
